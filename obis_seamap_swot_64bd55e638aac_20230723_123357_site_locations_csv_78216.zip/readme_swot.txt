Thank you for using the SWOT mapping application (http://seamap.env.duke.edu/swot) on OBIS-SEAMAP (http://seamap.env.duke.edu/).
You've downloaded SWOT nesting locations from the SWOT mapping application.

Please observe the SWOT Terms of Use, which is included in the zipped file, 
for your use of the data. Most important is that you are required to
give proper attribution (citation) to the dataset(s) / data provider(s) 
for the use of the data in any publication or product.


If you have questions regarding your download, please contact us at swotdata@gmail.com.

Thank you,

The SWOT Team
swotdata@gmail.com